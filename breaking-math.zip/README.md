# BREAKING MATH — The Equation Laboratory

Jogo de equações para navegador com visual inspirado em *Breaking Bad* e no pôster fornecido pelo usuário.

## Arquivos

- `index.html` — jogo completo (HTML, CSS e JavaScript).
- `poster-breaking-bad.jpg` — pôster usado no destaque principal.

## Como jogar

1. Abra `index.html` em um navegador moderno.
2. Escolha Iniciante, Intermediário ou Avançado.
3. Resolva cada equação escolhendo uma entre quatro alternativas.
4. Ao acertar, veja a cabra, a frase **you ar the Goat** e uma fala curta da série.
5. Use **Pular questão** para avançar sem ganhar ponto. Pular também zera a sequência de acertos.

O recorde pessoal fica salvo no navegador por `localStorage`.

## Publicar no GitHub Pages

1. Extraia este ZIP.
2. Envie os três arquivos (`index.html`, `poster-breaking-bad.jpg` e `README.md`) diretamente para a raiz do repositório — não envie apenas a pasta que contém os arquivos.
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`, depois salve.

O pôster está incluído no projeto. A imagem da cabra é carregada da Wikimedia Commons e precisa de conexão com a internet para aparecer.
